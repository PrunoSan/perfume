---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**lax.js version**
Please note, only bugs in v2.0 or later will be fixed.

**Describe the bug**
A clear and concise description of what the bug is.

**Code**
Please provide a link to a repo or code example of the issue in question.
